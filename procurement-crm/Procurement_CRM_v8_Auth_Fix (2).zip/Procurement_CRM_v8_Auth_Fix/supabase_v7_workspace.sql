-- Procurement CRM V6: shared central workspace snapshot
-- Run once in Supabase SQL Editor. This supplements the normalized procurement tables.
create table if not exists public.procurement_workspace (
  workspace_key text primary key check (workspace_key = 'main'),
  payload jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

alter table public.procurement_workspace enable row level security;

drop policy if exists "workspace_team_read" on public.procurement_workspace;
create policy "workspace_team_read"
on public.procurement_workspace for select to authenticated
using (public.is_active_member());

drop policy if exists "workspace_team_insert" on public.procurement_workspace;
create policy "workspace_team_insert"
on public.procurement_workspace for insert to authenticated
with check (public.is_active_member() and updated_by = auth.uid());

drop policy if exists "workspace_team_update" on public.procurement_workspace;
create policy "workspace_team_update"
on public.procurement_workspace for update to authenticated
using (public.is_active_member())
with check (public.is_active_member() and updated_by = auth.uid());

-- Enable realtime updates for the shared workspace (safe if already included).
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'procurement_workspace'
  ) then
    alter publication supabase_realtime add table public.procurement_workspace;
  end if;
end $$;
