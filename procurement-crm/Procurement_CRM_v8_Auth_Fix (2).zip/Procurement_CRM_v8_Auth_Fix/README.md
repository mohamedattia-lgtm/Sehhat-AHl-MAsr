# Procurement CRM V7 – Supabase-connected starter

## What this version adds
- Email/password login through Supabase Auth.
- Built-in password recovery request and password reset form. The recovery link redirects to the deployed site URL; after opening it, set a new CRM password (not Gmail App Password).
- Active profile check against `public.profiles`.
- Shared central workspace state persisted in `public.procurement_workspace`.
- Source Excel files uploaded to the private `procurement-files` Storage bucket.
- Realtime refresh when another team member updates the shared workspace.
- Uses the existing V5 PR/PO/receipt parsing and dashboard calculations.

## Required one-time setup
1. In Supabase SQL Editor, run `supabase_v7_workspace.sql`.
2. Confirm both existing profiles are active and roles are `admin` and `supervisor`.
3. Confirm the private `procurement-files` bucket and its four Storage policies exist.
4. Serve `index.html` over HTTPS (or localhost for testing). Do not open as a `file://` URL.
5. In Supabase Authentication → URL Configuration, set Site URL to the exact HTTPS Netlify site URL and add that same URL (plus `/**`) to Redirect URLs.
6. Sign in using an Auth user's email/password. To create/reset it, enter the company email on the login page and click “نسيت كلمة المرور؟”.

## Important architecture note
This V7 starter persists the app's normalized working datasets as a shared JSONB workspace record so the existing V5 screens can be connected without rewriting the whole UI at once. The previously created relational tables remain in place; a subsequent migration can populate/query them directly for reporting and stronger data governance. The JSONB workspace is suitable as an integration phase, not the final long-term design for very large data volumes.

## Security notes
- Only the Supabase publishable key is included in browser code. Never put a secret/service_role key in this file.
- Authenticated users must have an active `profiles` row.
- RLS controls workspace reads/writes. Storage policies control private source file access.
- The starter currently grants active team members shared workspace edit access. Fine-grained supervisor/specialist permissions and user administration UI must be hardened before production.
- The browser receives a single shared workspace payload. This is not field-level data isolation.

## Deployment
Deploy the folder to a static HTTPS host (for example, a static site host). Supabase provides Auth, database, Storage, and Realtime; it does not host this HTML page.


## V8 authentication recovery fix
- Explicitly detects Supabase recovery callbacks in the URL before normal session routing.
- Keeps the password-reset form visible while the recovery session is being processed.
- Enables URL-session detection and gives a clearer SDK-load error.
- This does not repair an unreachable Netlify hostname by itself. The updated folder must be deployed, and the exact deployed URL must remain in Supabase Authentication → URL Configuration (Site URL and Redirect URLs).
